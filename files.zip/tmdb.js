exports.handler = async function(event) {
    const TMDB_API_KEY = process.env.TMDB_API_KEY;

    if (!TMDB_API_KEY) {
        return { statusCode: 500, body: JSON.stringify({ error: 'API key not configured' }) };
    }

    const { path: moviePath, query } = event.queryStringParameters || {};

    if (!moviePath) {
        return { statusCode: 400, body: JSON.stringify({ error: 'Missing path parameter' }) };
    }

    // Build the TMDb URL — only allow safe endpoints
    const allowedPaths = ['/search/movie', '/movie/'];
    const isAllowed = allowedPaths.some(p => moviePath.startsWith(p));
    if (!isAllowed) {
        return { statusCode: 403, body: JSON.stringify({ error: 'Endpoint not allowed' }) };
    }

    const params = new URLSearchParams({ api_key: TMDB_API_KEY, language: 'en-US' });
    if (query) params.set('query', query);

    const url = `https://api.themoviedb.org/3${moviePath}?${params.toString()}&include_adult=false`;

    try {
        const res = await fetch(url);
        const data = await res.json();
        return {
            statusCode: 200,
            headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
            body: JSON.stringify(data)
        };
    } catch (err) {
        return { statusCode: 502, body: JSON.stringify({ error: 'TMDb request failed' }) };
    }
};
